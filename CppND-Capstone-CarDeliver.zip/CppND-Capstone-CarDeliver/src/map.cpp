#include "map.h"
#include <SDL2/SDL_image.h>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

Map::Map(SDL_Renderer *renderer, int mapWidth, int mapHeight, int tileSize)
{
    this->renderer = renderer;
    this->mapWidth = mapWidth;
    this->mapHeight = mapHeight;
    this->tileSize = tileSize;
    tilesetSurface = IMG_Load("../assets/sTiles.png");
    tilesetTexture = SDL_CreateTextureFromSurface(renderer, tilesetSurface);
    tileMap.resize(mapHeight, std::vector<int>(mapWidth, 0));
}

Map::~Map()
{
    SDL_DestroyTexture(tilesetTexture);
}

std::vector<std::vector<int>> Map::LoadMap()
{
    std::vector<std::vector<int>> map;
    std::ifstream file("../src/map.data");
    if (file.is_open())
    {
        std::string line;
        while (std::getline(file, line))
        {
            std::vector<int> row;
            std::stringstream ss(line);
            std::string cell;
            while (std::getline(ss, cell, ','))
            {
                row.push_back(std::stoi(cell));
            }

            map.push_back(row);
        }

        file.close();
    }
    tileMap = map;
    return tileMap;
}

std::vector<std::vector<int>> Map::GetMap(){
    return tileMap;
}

SDL_Texture *Map::GetTileTexture(int tileId)
{
    SDL_Rect srcRect;
    srcRect.x = (tileId % (tilesetSurface->w / tileSize)) * tileSize;
    srcRect.y = (tileId / (tilesetSurface->w / tileSize)) * tileSize;
    srcRect.w = tileSize;
    srcRect.h = tileSize;

    SDL_Texture *tileTexture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, tileSize, tileSize);
    SDL_SetRenderTarget(renderer, tileTexture);
    SDL_RenderCopy(renderer, tilesetTexture, &srcRect, NULL);
    SDL_SetRenderTarget(renderer, NULL);

    return tileTexture;
}

void Map::Render(int option)
{
    // SDL_SetRenderDrawColor(renderer, 51, 102, 0, 255);
    if (option == 1)
    {
        SDL_Surface* bg = IMG_Load("../assets/map.png");
        SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, bg);
        SDL_RenderCopy(renderer, texture, NULL, NULL);
        SDL_FreeSurface(bg);
    }
    else
    {
        for (int y = 0; y < mapHeight; ++y)
        {
            for (int x = 0; x < mapWidth; x++)
            {
                int tileId = tileMap[y][x];
                if (tileId != -1)
                {
                    SDL_Texture *tileTexture = GetTileTexture(tileId);

                    SDL_Rect destRect;
                    destRect.x = x * tileSize;
                    destRect.y = y * tileSize;
                    destRect.w = tileSize;
                    destRect.h = tileSize;

                    SDL_RenderCopy(renderer, tileTexture, NULL, &destRect);
                    SDL_DestroyTexture(tileTexture);
                }
                else
                {
                    SDL_Rect block;
                    block.x = x * tileSize;
                    block.y = y * tileSize;
                    block.w = tileSize;
                    block.h = tileSize;

                    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
                    SDL_RenderFillRect(renderer, &block);
                }
            }
        }
    }
}