#include <iostream>
#include "game.h"

int main() {
  constexpr std::size_t kFramesPerSecond{60};
  constexpr std::size_t kMsPerFrame{1000 / kFramesPerSecond};
  constexpr std::size_t kScreenWidth{640};
  constexpr std::size_t kScreenHeight{640};
  constexpr std::size_t kGridWidth{32};
  constexpr std::size_t kGridHeight{32};

  Game game;
  if(game.Init()){
    game.Run(kMsPerFrame);
    game.CleanUp();
  } else {
    std::cerr<<"Failed to initialize the game !"<<std::endl;
    return 1;
  }
  return 0;
}