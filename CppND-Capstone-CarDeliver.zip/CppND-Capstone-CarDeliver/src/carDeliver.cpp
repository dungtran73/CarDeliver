#include "carDeliver.h"
#include "game.h"
#include <algorithm>

const int CAR_SIZE = 60;

CarDeliver::CarDeliver(SDL_Renderer *renderer, int x, int y)
{
    this->x = x;
    this->y = y;
    this->renderer = renderer;
    carRect.x = x;
    carRect.y = y;
    carRect.h = CAR_SIZE;
    carRect.w = CAR_SIZE;
    speed = 0;
    acceleration = 0.05;
    accelerating = false;
    direction = CarDirection::Right;

    loadTexture();
}

CarDeliver::~CarDeliver()
{
    SDL_DestroyTexture(carTexture);
}

void CarDeliver::HandleInput(SDL_Event &event)
{
    if (event.type == SDL_KEYDOWN)
    {
        switch (event.key.keysym.sym)
        {
        case SDLK_UP:
            if (!isOppositeDirection(CarDirection::Up))
            {
                accelerating = true;
                SetDirection(CarDirection::Up);
            }
            break;
        case SDLK_DOWN:
            if (!isOppositeDirection(CarDirection::Down))
            {
                accelerating = true;
                SetDirection(CarDirection::Down);
            }
            break;
        case SDLK_LEFT:
            if (!isOppositeDirection(CarDirection::Left))
            {
                accelerating = true;
                SetDirection(CarDirection::Left);
            }
            break;
        case SDLK_RIGHT:
            if (!isOppositeDirection(CarDirection::Right))
            {
                accelerating = true;
                SetDirection(CarDirection::Right);
            }
            break;
        }
    }
    else if (event.type == SDL_KEYUP)
    {
        accelerating = false;
    }
}

void CarDeliver::HandlePressKey()
{
    if (accelerating)
    {
        speed += acceleration;
        if (speed >= MAX_SPEED)
            speed = MAX_SPEED;
        if ((carRect.x <= 0 && direction == CarDirection::Left) || (carRect.x >= 720 - carRect.w && direction == CarDirection::Right) || (carRect.y <= 0 && direction == CarDirection::Up) || (carRect.y >= 600 - carRect.h && direction == CarDirection::Down))
        {
            speed = 0;
        }
    }
    else
    {
        speed = 0;
        return;
    }

    newX = x;
    newY = y;
    
    switch (direction)
    {
    case CarDirection::Up:
        newY -= speed;
        break;
    case CarDirection::Down:
        
        newY += speed;
        break;
    case CarDirection::Left:
        
        newX -= speed;
        break;
    case CarDirection::Right:
        
        newX += speed;
        break;
    }
    
    bool isBlocked = isCollisionWithObstacle();
    if (!isBlocked) {
        blockedDirection = CarDirection::Null;
    }
    if(accelerating && ( !isBlocked || isOppositeDirection(blockedDirection) )){
        x = newX;
        y = newY;
        carRect.x = x;
        carRect.y = y;
        return;
    }
    
    if(isBlocked){
        blockedDirection = direction;
    }
}

void CarDeliver::SetDirection(CarDirection direction)
{
    this->direction = direction;
}

bool CarDeliver::isOppositeDirection(CarDirection move)
{
    switch (direction)
    {
    case CarDirection::Up:
        return move == CarDirection::Down;
    case CarDirection::Down:
        return move == CarDirection::Up;
    case CarDirection::Left:
        return move == CarDirection::Right;
    case CarDirection::Right:
        return move == CarDirection::Left;
    }
    return false;
}

void CarDeliver::Render()
{
    SDL_Rect srcRect;
    switch (direction)
    {
    case CarDirection::Right:
        srcRect.x = 0;
        srcRect.y = 0;
        break;
    case CarDirection::Up:
        srcRect.x = 0;
        srcRect.y = carRect.h;
        break;
    case CarDirection::Left:
        srcRect.x = 0;
        srcRect.y = carRect.h * 2;
        break;
    case CarDirection::Down:
        srcRect.x = 0;
        srcRect.y = carRect.h * 3;
    default:
        break;
    }

    srcRect.w = carRect.w;
    srcRect.h = carRect.h;

    SDL_RenderCopy(renderer, carTexture, &srcRect, &carRect);
}

void CarDeliver::Update()
{
    Render();
    HandlePressKey();
}

void CarDeliver::SetMap(std::vector<std::vector<int>> map)
{
    this->map = map;
}

void CarDeliver::loadTexture()
{
    SDL_Surface *sf = IMG_Load("../assets/car.png");
    carTexture = SDL_CreateTextureFromSurface(renderer, sf);
    SDL_FreeSurface(sf);
}

bool CarDeliver::isCollisionWithObstacle()
{
    int tileSize = 12;
    int maxI, maxJ, i, j;
    i = x / tileSize;
    j = y / tileSize;
    maxI = i + carRect.w / tileSize;
    maxJ = j + carRect.h / tileSize;
    maxI = maxI < 60 ? maxI : 60;
    maxJ = maxJ < 50 ? maxJ : 50;

    for (; j < maxJ; j++)
    {
        for (; i < maxI; i++)
        {
            int tileId = map[j][i];
            if (std::find(obstacleIds.begin(), obstacleIds.end(), tileId) != obstacleIds.end())
            {
                SDL_Rect ob;
                ob.x = i * tileSize;
                ob.y = j * tileSize;
                ob.h = tileSize/2;
                ob.w = tileSize/2;

                SDL_Rect newRect = {int(newX), int(newY), carRect.w, carRect.h};
                if(checkAABBCollision(ob, carRect, newRect, direction))
                {
                    return true;
                }
            }
        }
    }

    return false;
}

bool CarDeliver::checkAABBCollision(const SDL_Rect& a, const SDL_Rect& b, const SDL_Rect& c, CarDirection d){
    bool xOverlap, yOverlap;
    switch (d)
    {
    case CarDirection::Up:
        xOverlap = (a.x + a.w >= b.x) && (a.x <= c.x + c.w);
        yOverlap = (a.y <= b.y) && (a.y + a.h >= c.y);
        break;
    case CarDirection::Down:
        xOverlap = (a.x + a.w >= b.x) && (a.x <= c.x + c.w);
        yOverlap = (a.y + a.h >= b.y) && (a.y + a.h <= c.y + c.h);
        break;
    case CarDirection::Left:
        xOverlap = (a.x + a.w >= b.x) && (a.x <= c.x);
        yOverlap = (a.y <= b.y + b.h) && (a.y + a.h >= c.y);
        break;
    case CarDirection::Right:
        xOverlap = (a.x >= b.x) && (a.x <= b.x + b.w);
        yOverlap = (a.y <= b.y + b.h) && (a.y + a.h >= c.y);
        break;
    }

    return xOverlap && yOverlap;
}

bool CarDeliver::isCollision(SDL_Rect other)
{
    if (x + carRect.w > other.x && x < other.x + other.w && y + carRect.h > other.y && y < other.y + other.h)
    {
        return true;
    }
    return false;
}

bool CarDeliver::isCollisionWithObstacle(float xx, float yy){

    return false;
}