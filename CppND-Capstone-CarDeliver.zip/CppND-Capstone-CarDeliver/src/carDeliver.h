#ifndef CAR_H
#define CAR_H

#define MAX_SPEED 2

#include <SDL2/SDL.h>
#include <vector>
#include <SDL2/SDL_image.h>
#include "map.h"

enum class CarDirection {
    Up,
    Down,
    Left,
    Right,
    Null
};

class CarDeliver {
public:
    CarDeliver(SDL_Renderer* renderer, int x, int y);
    ~CarDeliver();

    void HandleInput(SDL_Event& event);
    void Update();
    void Render();
    void SetDirection(CarDirection direction);
    void HandlePressKey();
    void SetMap(std::vector<std::vector<int>> map);
    bool isCollision(SDL_Rect other);
private:
    SDL_Renderer* renderer;
    SDL_Texture* carTexture;
    SDL_Rect carRect;
    float x, y;
    float speed;
    bool accelerating;
    float newY, newX;
    float acceleration;
    CarDirection blockedDirection;
    CarDirection direction;


    std::vector<int> obstacleIds = {125,126,127,128,308,155,156,157,158,338,185,186,187,188,368,215,216,217,218,398,245,246,247,248};
    std::vector<std::vector<int>> map;

    void loadTexture();
    bool isOppositeDirection(CarDirection move);
    bool isCollisionWithObstacle();
    bool isCollisionWithObstacle(float, float);
    bool checkAABBCollision(const SDL_Rect& a, const SDL_Rect& b, const SDL_Rect& c, CarDirection d);
};

#endif