#ifndef ASSET_MNG
#define ASSET_MNG

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <string>
#include <map>
#include <fstream>

class AssetManager {
public:
    AssetManager();
    ~AssetManager();

    bool loadTexture(const std::string& filePath, const std::string& id);
    SDL_Texture* getTexture(const std::string& id);
    bool loadAssetsFromFile(const std::string& filePath);
    void setRenderer(SDL_Renderer* renderer);
private:
    SDL_Renderer* renderer;
    std::map<std::string , SDL_Texture*> textures;
};

#endif