#include "game.h"
#include "SDL.h"
#include "map.h"
#include "carDeliver.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>



Game::Game()
{
  window = nullptr;
  renderer = nullptr;
  isLoading = true;
  isGameOver = false;
}

Game::~Game() {}

bool Game::Init()
{

  if (SDL_Init(SDL_INIT_VIDEO) != 0)
  {
    SDL_Log("SDL_Init Error: %s", SDL_GetError());
    return false;
  }

  window = SDL_CreateWindow("Car Deliver", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 720, 600, SDL_WINDOW_SHOWN);
  if (!window)
  {
    SDL_Log("SDL_CreateWindow Error: %s", SDL_GetError());
    return false;
  }

  renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
  if (!renderer)
  {
    SDL_Log("SDL_CreateRenderer Error: %s", SDL_GetError());
    return false;
  }

  assetManager.setRenderer(this->renderer);
  if (!assetManager.loadAssetsFromFile("../src/assets.data"))
  {
    SDL_Log("Load assets failed.");
  };

  TTF_Init();
  font = TTF_OpenFont("../fonts/font.ttf", 24);
  font36 = TTF_OpenFont("../fonts/font.ttf", 36);
  if (!font)
  {
    SDL_Log("TTF Init Error: %s", SDL_GetError());
    return false;
  }

  star = assetManager.getTexture("star");
  score = 0;
  timeElapsed = 10;
  isLoading = false;
  return true;
}

void Game::Run(std::size_t targetFrameDuration)
{
  SDL_Event event;

  Uint32 frameStart, frameEnd, frameDuration, startTime;
  startTime = SDL_GetTicks();

  Map map(renderer, Game::mapWidth, Game::mapHeight, 12);
  tileMap = map.LoadMap();

  CarDeliver car(renderer, 60, 185);
  car.SetMap(tileMap);

  SDL_Rect srcRect = {0, 0, 32, 32};

  SDL_Rect starRect;
  std::vector<int> randomPosition = Game::createRandomStarPosition();
  starRect.x = randomPosition[0];
  starRect.y = randomPosition[1];
  starRect.w = 32;
  starRect.h = 32;

  bool isRunning = true;
  while (isRunning)
  {
    while (SDL_PollEvent(&event) != 0)
    {
      if (event.type == SDL_QUIT)
      {
        isRunning = false;
      }
      else if (event.type == SDL_MOUSEBUTTONDOWN && isGameOver)
      {
        isGameOver = false;
        timeElapsed = 10;
        score = 0;
        startTime = SDL_GetTicks();
      }
      else
      {
        car.HandleInput(event);
      }
    }

    if (!isGameOver)
    {
      frameStart = SDL_GetTicks();

      SDL_SetRenderDrawColor(renderer, 0x1E, 0x1E, 0x1E, 0xFF);
      SDL_RenderClear(renderer);

      map.Render(1);
      car.Update();
      Game::renderScore();
      Game::renderTimeElapsed();
      SDL_RenderCopy(renderer, star, &srcRect, &starRect);

      if (car.isCollision(starRect))
      {
        ++score;
        randomPosition = Game::createRandomStarPosition();
        starRect.x = randomPosition[0];
        starRect.y = randomPosition[1];

        timeElapsed = 10;
        startTime = SDL_GetTicks();
      }

      SDL_RenderPresent(renderer);
      frameEnd = SDL_GetTicks();
      frameDuration = frameEnd - frameStart;
      Uint32 eTime = frameEnd - startTime;
      int remainSeconds = 10 - (eTime / 1000);
      timeElapsed = remainSeconds;
      Game::checkGameOver();
      if (frameDuration < targetFrameDuration)
      {
        SDL_Delay(targetFrameDuration - frameDuration);
      }
    }
    else
    {
      SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
      SDL_RenderClear(renderer);

      SDL_Color color = {255, 61, 3};
      std::string gameOverText = "Game Over! Click to replay.";
      SDL_Surface *tf = TTF_RenderText_Solid(font, gameOverText.c_str(), color);
      SDL_Texture *gameOverTx = SDL_CreateTextureFromSurface(renderer, tf);
      SDL_FreeSurface(tf);

      SDL_Rect pos;
      pos.x = (720 - tf->w) / 2;
      pos.y = (600 - tf->h) / 2;
      pos.w = tf->w;
      pos.h = tf->h;

      SDL_RenderCopy(renderer, gameOverTx, nullptr, &pos);
      SDL_DestroyTexture(gameOverTx);
      SDL_RenderPresent(renderer);
    }
  }
}

void Game::CleanUp()
{
  TTF_CloseFont(font);
  TTF_CloseFont(font36);
  SDL_DestroyRenderer(renderer);
  SDL_DestroyWindow(window);
  SDL_Quit();
}

void Game::checkGameOver()
{
  if (timeElapsed <= 0)
  {
    SDL_Log("GAME OVER");
    timeElapsed = 0;
    isGameOver = true;
  }
}

std::vector<int> Game::createRandomStarPosition()
{
  std::srand(static_cast<unsigned int>(std::time(nullptr)));
  int rdX[4] = {12, 25, 33, 49};

  int xTh = std::rand() % 4;
  int x, y;
  switch (rdX[xTh])
  {
  case 12:
    x = 12;
    y = std::rand() % 3 + 17;
    break;
  case 25:
    x = std::rand() % 7 + 25;
    y = std::rand() % 37 + 2;
    break;
  case 33:
    x = std::rand() % (58 - 26) + 26;
    y = 33;
    break;
  case 49:
    x = 49;
    y = std::rand() % 37 + 2;
    break;
  }

  return {x * 12, y * 12};
}

void Game::renderScore()
{
  SDL_Color textColor = {222, 222, 38};
  std::string scoreText = "Score: " + std::to_string(score);
  SDL_Surface *textSf = TTF_RenderText_Solid(font, scoreText.c_str(), textColor);
  SDL_Texture *textTexture = SDL_CreateTextureFromSurface(renderer, textSf);
  SDL_FreeSurface(textSf);

  SDL_Rect rect;
  rect.x = 720 - textSf->w - 10;
  rect.y = 10;
  rect.w = textSf->w;
  rect.h = textSf->h;

  SDL_RenderCopy(renderer, textTexture, nullptr, &rect);
  SDL_DestroyTexture(textTexture);
}

void Game::renderTimeElapsed()
{
  SDL_Color textColor = {255, 61, 3};
  std::string secondText = std::to_string(timeElapsed);
  SDL_Surface *textSf = TTF_RenderText_Solid(font36, secondText.c_str(), textColor);
  SDL_Texture *textTexture = SDL_CreateTextureFromSurface(renderer, textSf);
  SDL_FreeSurface(textSf);

  SDL_Rect rect;
  rect.x = (720 - textSf->w) / 2;
  rect.y = 5;
  rect.w = textSf->w;
  rect.h = textSf->h;

  SDL_RenderCopy(renderer, textTexture, nullptr, &rect);
  SDL_DestroyTexture(textTexture);
}