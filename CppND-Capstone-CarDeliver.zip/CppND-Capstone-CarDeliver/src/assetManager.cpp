#include "assetManager.h"
#include <sstream>
#include <fstream>

AssetManager::AssetManager(){}

AssetManager::~AssetManager(){
    for(auto& pair : textures){
        SDL_DestroyTexture(pair.second);
    }
    textures.clear();
}

void AssetManager::setRenderer(SDL_Renderer* renderer){
    this->renderer = renderer;
}

bool AssetManager::loadTexture(const std::string& filePath, const std::string& id){
    SDL_Surface* surface = IMG_Load(filePath.c_str());
    if(!surface){
        return false;
    }
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_FreeSurface(surface);

    if(!texture){
        return false;
    }
    textures[id] = texture;
    return true;
}

SDL_Texture* AssetManager::getTexture(const std::string& id){
    if(textures.find(id) != textures.end()){
        return textures[id];
    }
    return nullptr;
}

bool AssetManager::loadAssetsFromFile(const std::string& filePath){
    std::ifstream file(filePath);
    if(!file.is_open()){
        return false;
    }

    std::string line;
    while(std::getline(file, line)){
        std::istringstream iss(line);
        std::string path, id;
        iss>>path>>id;
        if(!loadTexture(path, id)){
            return false;
        }
    }
    return true;
}