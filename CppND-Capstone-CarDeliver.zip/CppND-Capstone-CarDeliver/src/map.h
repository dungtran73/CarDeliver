#ifndef MAP_H
#define MAP_H

#include <SDL2/SDL.h>
#include <vector>

class Map {
public:
    Map(SDL_Renderer* renderer, int mapWidth, int mapHeight, int tileSize);
    ~Map();

    std::vector<std::vector<int>> LoadMap();
    void Render(int option);
    SDL_Texture* GetTileTexture(int tileId);
    std::vector<std::vector<int>> GetMap();

private:
    SDL_Renderer* renderer;
    int mapWidth;
    int mapHeight;
    int tileSize;
    SDL_Texture* tilesetTexture;
    SDL_Surface* tilesetSurface;
    std::vector<std::vector<int>> tileMap;
};

#endif