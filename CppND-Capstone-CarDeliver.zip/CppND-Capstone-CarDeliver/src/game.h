#ifndef GAME_H
#define GAME_H

#include <random>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include "assetManager.h"

class Game
{
public:
  Game();
  ~Game();

  bool Init();
  void Run(std::size_t targetFrameDuration);
  void CleanUp();

  static const int mapWidth = 60;
  static const int mapHeight = 50;
  
private:
  bool isLoading;
  SDL_Window* window;
  SDL_Renderer* renderer;
  AssetManager assetManager;
  std::vector<std::vector<int>> tileMap;
  SDL_Texture* star;
  TTF_Font* font;
  TTF_Font* font36;
  int score;
  int timeElapsed;
  bool isGameOver;

  std::vector<int> createRandomStarPosition();
  void renderScore();
  void renderTimeElapsed();
  void checkGameOver();
};

#endif